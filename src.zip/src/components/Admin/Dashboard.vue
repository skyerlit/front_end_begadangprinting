<template>
  <v-main>
    <h1 class="text-h3 font-weight-medium mb-5">Dashboard</h1>
    <p class="subtitle-1">Ini Dashboard</p>
  </v-main>
</template>
